package com.choose;

import java.util.Random;

public class Root
{
	public static void main(String[] args)
	{
		Students students = new Students();
		Patterns patterns = new Patterns();
		
		DateList dateone = new DateList();
		
		Random rand = new Random();

		for(String student : students.getList())
		{
			
			int listSize = patterns.getList().size();
			int index = (rand.nextInt(listSize - 1));
			
			while(patterns.getList().size() > listSize - 2)
			{
				if(dateone.list.size() <= 1)
				{
					dateone.init();
				}
				int dateSize = dateone.list.size();
				int dateIndex = (rand.nextInt(dateSize - 1));
			
				System.out.println(student + " gets " + patterns.getList().get(index).getPatternName() + " on week " + dateone.list.get(dateIndex));
				patterns.removeItem(index);
				dateone.list.remove(dateIndex);
				
			}
		}
		
	}
}
