package com.choose;

import java.util.ArrayList;


public class Patterns
{
	public ArrayList<Pattern> list = new ArrayList<Pattern>();	
	
	Patterns()
	{
		this.list.add(new Pattern("Abstract factory"));
		this.list.add(new Pattern("Builder"));
		this.list.add(new Pattern("Factory method"));
		this.list.add(new Pattern("Lazy initialization"));
		this.list.add(new Pattern("Multiton"));
		this.list.add(new Pattern("Object pool"));
		this.list.add(new Pattern("Prototype"));
		this.list.add(new Pattern("Singleton"));
		this.list.add(new Pattern("Bridge"));
		this.list.add(new Pattern("Adapter"));
		this.list.add(new Pattern("Composite"));
		this.list.add(new Pattern("Facade"));
		this.list.add(new Pattern("Module"));
		this.list.add(new Pattern("Proxy"));
		this.list.add(new Pattern("Twin"));
		this.list.add(new Pattern("Blackboard"));
		this.list.add(new Pattern("Chain of responsibility"));
		this.list.add(new Pattern("Command"));
		this.list.add(new Pattern("Interpreter"));
		this.list.add(new Pattern("Iterator"));
		this.list.add(new Pattern("Mediator"));
		this.list.add(new Pattern("Null object"));
		this.list.add(new Pattern("Servant"));
		this.list.add(new Pattern("State"));
		//24 events
		
	}

	public ArrayList<Pattern> getList() {
		return list;
	}

	public void setList(ArrayList<Pattern> list) {
		this.list = list;
	}

	public void removeItem(int index)
	{
		this.list.remove(index);
	}

	
}
