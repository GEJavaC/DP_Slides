package com.choose;

import java.util.ArrayList;

public class Students 
{
	public ArrayList<String> list = new ArrayList<String>();	
	
	public Students()
	{
		this.list.add("Sachin");
		this.list.add("Chris");
		this.list.add("Kody");
		this.list.add("Andrew");
		this.list.add("Dominique");
		this.list.add("Sarah");
		this.list.add("Robert");
		this.list.add("Tommy");
		this.list.add("Perrin");
		this.list.add("Matt");
		this.list.add("Blair");
		this.list.add("Sachin");
		//12 people
	}

	public ArrayList<String> getList(){
		return list;
	}

	public void setList(ArrayList<String> list){
		this.list = list;
	}
	

	public void removeItem(int index)
	{
		this.list.remove(index);
	}


	
}
