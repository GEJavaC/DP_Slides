package com.choose;

import java.util.ArrayList;

public class DateList 
{
	ArrayList<Integer> list = new ArrayList<Integer>();
	
	DateList()
	{
		init();
	}
	void init()
	{
		for(int i = 1; i <=13; i++)
		{
			list.add(i);
		}	
	}
}
