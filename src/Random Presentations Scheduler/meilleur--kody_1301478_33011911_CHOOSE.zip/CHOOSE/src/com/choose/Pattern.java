package com.choose;

public class Pattern 
{
	String patternName;
	int date;
	
	Pattern(){}
	Pattern(String pattern, int date)
	{
		this.patternName = pattern;
		this.date = date;
		
	}
	Pattern(String pattern)
	{
		this.patternName = pattern;	
	}
	public String getPatternName() {
		return patternName;
	}
	public void setPatternName(String patternName) {
		this.patternName = patternName;
	}
	public int getDate() {
		return date;
	}
	public void setDate(int date) {
		this.date = date;
	}
	
}
