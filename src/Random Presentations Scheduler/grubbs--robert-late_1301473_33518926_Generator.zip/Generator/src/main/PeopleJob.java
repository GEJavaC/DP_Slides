package main;

import java.util.ArrayList;

public class PeopleJob {
	
	String personName;
	String jobName;
	
	public PeopleJob() {
		personName = "John Doe";
		jobName = "Software Developer";
	}
	public PeopleJob(String person, String job) {
		this.personName = person;
		this.jobName = job; 
	}
	
	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

}
