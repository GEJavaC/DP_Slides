package controller;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;



import model.Pattern;
import model.Player;
import data.PatternFactory;
import data.PlayerCharacterFactory;

public class RandomGenerator 
{
	private List<Player> player = (new PlayerCharacterFactory()).createCharacter();
	private List<Pattern> pattern = (new PatternFactory()).createPatternFactory();
	
	Random rand = new Random();
	private long seed = System.nanoTime();
	
	public static void main (String []args)
	{
		
		List<String> player = (new RandomGenerator()).player();
		List<String> patternOne = (new RandomGenerator()).patternOne();
		List<String> patternTwo = (new RandomGenerator()).patternTwo();
		
		System.out.println("First Iteration\n-------------------------------------------\n");
		
		for(int i = 0; i < 12; i++)
		{
			
			System.out.println("Student:" + player.get(i) + "\t\t"  +"Pattern First Batch: " + patternOne.get(i));
		}
		
		System.out.println("\nSecond Iteration\n-------------------------------------------\n");
		
		for(int i = 0; i < 12; i++)
		{
			
			System.out.println("Student:" + player.get(i) + "\t\t" + "Pattern Second Batch: " + patternTwo.get(i));
		}	
		 		
	}
	
	
	
	public List<String> player()
	{
		List<String> strPlayer = new ArrayList<String>();
		
		
		for(int i = 0; i < player.size(); /**i--**/)
		 {
			
			 strPlayer.add(player.get(0).getName().trim());
			 strPlayer.add(player.get(1).getName().trim());
			 strPlayer.add(player.get(2).getName().trim());
			 strPlayer.add(player.get(3).getName().trim());
			 strPlayer.add(player.get(4).getName().trim());
			 strPlayer.add(player.get(5).getName().trim());
			 strPlayer.add(player.get(6).getName().trim());
			 strPlayer.add(player.get(7).getName().trim());
			 strPlayer.add(player.get(8).getName().trim());
			 strPlayer.add(player.get(9).getName().trim());
			 strPlayer.add(player.get(10).getName().trim());
			 strPlayer.add(player.get(11).getName().trim());
			
			 break; 
		 }
		 
		 
		return strPlayer;
	}//end of player method
	
	
	public List<String> patternOne()
	{
		List<String> strPattern = new ArrayList<String>();
		
		for(int i = 0; i < pattern.size(); /**i++**/)
		 {
			 
			
			
			strPattern.add(pattern.get(0).getPatternName().trim());
			strPattern.add(pattern.get(1).getPatternName().trim());
			strPattern.add(pattern.get(2).getPatternName().trim());
			strPattern.add(pattern.get(3).getPatternName().trim());
			strPattern.add(pattern.get(4).getPatternName().trim());
			strPattern.add(pattern.get(5).getPatternName().trim());
			strPattern.add(pattern.get(6).getPatternName().trim());
			strPattern.add(pattern.get(7).getPatternName().trim());
			strPattern.add(pattern.get(8).getPatternName().trim());
			strPattern.add(pattern.get(9).getPatternName().trim());
			strPattern.add(pattern.get(10).getPatternName().trim());
			strPattern.add(pattern.get(11).getPatternName().trim());
			break;
			
			 
		 }
		Collections.shuffle(strPattern, new Random(seed));
		
		return strPattern;	
	}//end of pattern one method
	
	
	
	public List<String> patternTwo()
	{
		List<String> strPattern2 = new ArrayList<String>();
		
		for(int i = 0; i < pattern.size(); /**i++**/)
		 {
			
			 
			 strPattern2.add(pattern.get(12).getPatternName().trim());
			 strPattern2.add(pattern.get(13).getPatternName().trim());
			 strPattern2.add(pattern.get(14).getPatternName().trim());
			 strPattern2.add(pattern.get(15).getPatternName().trim());
			 strPattern2.add(pattern.get(16).getPatternName().trim());
			 strPattern2.add(pattern.get(17).getPatternName().trim());
			 strPattern2.add(pattern.get(18).getPatternName().trim());
			 strPattern2.add(pattern.get(19).getPatternName().trim());
			 strPattern2.add(pattern.get(20).getPatternName().trim());
			 strPattern2.add(pattern.get(21).getPatternName().trim());
			 strPattern2.add(pattern.get(22).getPatternName().trim());
			 strPattern2.add(pattern.get(23).getPatternName().trim());
			
			 break;	 
			
		 }
		
		Collections.shuffle(strPattern2, new Random(seed));
		return strPattern2;
			
	}//end of pattern two method
	
	
	
	
}//end class

