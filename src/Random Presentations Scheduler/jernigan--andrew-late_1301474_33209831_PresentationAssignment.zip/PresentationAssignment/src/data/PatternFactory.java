package data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import model.Player;
import model.Pattern;

public class PatternFactory 
{
	
	private List<Pattern> patternName;

	public PatternFactory()
	{
		setPatternFactory(this.patternName);
	
	}
	

	public List<Pattern> createPatternFactory() 
	{
		 
		 //create the objects of player
		 Pattern abstractFactory = new Pattern("Abstract Factory");
		 Pattern builder = new Pattern("Builder");
		 Pattern factoryMethod = new Pattern("Factory Method");
		 Pattern lazyInitialization = new Pattern("Lazy Initialization");
		 Pattern multiton = new Pattern("Multiton");
		 Pattern objectPool = new Pattern("Object Pool");
		 Pattern prototype = new Pattern("Prototype");
		 Pattern singleton = new Pattern("Singleton");
		 Pattern bridge = new Pattern("Bridge");
		 Pattern adapter = new Pattern("Adapter");
		 Pattern composite = new Pattern("Composite ");
		 Pattern facade = new Pattern("Facade");
		 Pattern module = new Pattern("Module");
		 Pattern proxy = new Pattern("Proxy");
		 Pattern twin = new Pattern("Twin");
		 Pattern blackBoard = new Pattern("Blackboard");
		 Pattern chainOfResponsibility = new Pattern("Chain Of Responsibility");
		 Pattern command = new Pattern("Command");
		 Pattern interpreter = new Pattern("Interpreter");
		 Pattern iterator = new Pattern("Iterator");
		 Pattern mediator = new Pattern("Mediator");
		 Pattern nullObject = new Pattern("Null Object");
		 Pattern servant = new Pattern("Servant");
		 Pattern state = new Pattern("State");
	     
		 //add to the players to the array list 
	     List<Pattern> listOfPatterns = new ArrayList<Pattern>();
	     listOfPatterns.add(abstractFactory);
	     listOfPatterns.add(builder);
	     listOfPatterns.add(factoryMethod);
	     listOfPatterns.add(lazyInitialization);
	     listOfPatterns.add(multiton);
	     listOfPatterns.add(objectPool);
	     listOfPatterns.add(prototype);
	     listOfPatterns.add(singleton);
	     listOfPatterns.add(bridge);
	     listOfPatterns.add(adapter);
	     listOfPatterns.add(composite);
	     listOfPatterns.add(facade);
	     listOfPatterns.add(module);
	     listOfPatterns.add(proxy);
	     listOfPatterns.add(twin);
	     listOfPatterns.add(blackBoard);
	     listOfPatterns.add(chainOfResponsibility);
	     listOfPatterns.add(command);
	     listOfPatterns.add(interpreter);
	     listOfPatterns.add(iterator);
	     listOfPatterns.add(mediator);
	     listOfPatterns.add(nullObject);
	     listOfPatterns.add(servant);
	     listOfPatterns.add(state);
	     
	     
		return listOfPatterns;
		
		
	}
	
	
	public void setPatternFactory(List<Pattern> patternName)
	{
		
		this.patternName = patternName;
		
		
	}

}
