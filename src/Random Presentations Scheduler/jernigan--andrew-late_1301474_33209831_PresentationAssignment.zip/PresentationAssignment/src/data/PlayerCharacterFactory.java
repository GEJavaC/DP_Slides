package data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import model.Player;



public class PlayerCharacterFactory{

	private List<Player> playerName;

	public PlayerCharacterFactory( )
	{
	
		setCreateCharacter(this.playerName);
		
	}
	

	public List<Player> createCharacter() 
	{
		 
		 //create the objects of player
		 Player hafsa = new Player("hafsa Vahidy");
		 Player perrin = new Player("Perrin Lake");
		 Player andrew = new Player("Andrew Jernigan");
		 Player dominique = new Player("Dominique Glenn");
		 Player tommie = new Player("Tommie Cobb");
		 Player matt = new Player("Matt Mcmillian");
		 Player kody = new Player("Kody Milieuer");
		 Player chris = new Player("Chris Colon");
		 Player blair = new Player("Demetria Blair");
		 Player sachin = new Player("Sachin Gargesh");
		 Player sarah = new Player("Sarah Hood");
		 Player robert = new Player("Robert Grubbs");
	     
		 //add to the players to the array list 
		 List<Player> listOfPlayers = new ArrayList<Player>();
		 listOfPlayers.add(hafsa);
	     listOfPlayers.add(perrin);
	     listOfPlayers.add(andrew);
	     listOfPlayers.add(dominique);
	     listOfPlayers.add(tommie);
	     listOfPlayers.add(matt);
	     listOfPlayers.add(kody);
	     listOfPlayers.add(chris);
	     listOfPlayers.add(blair);
	     listOfPlayers.add(sachin);
	     listOfPlayers.add(sarah);
	     listOfPlayers.add(robert);
	     
		
		return listOfPlayers;
		
		
	}
	
	
	public void setCreateCharacter(List<Player>	playerName)
	{
		
		this.playerName = playerName;
		
		
	}
	
	
	

}
