package model;

public class Pattern 
{
	
private String patternName;
	
	

	public Pattern( String name )
	{
		this.setPatternName(name);
		
	}

	public String getPatternName() {
		return patternName;
	}

	public void setPatternName(String name) {
		this.patternName = name;
	}
	
}
